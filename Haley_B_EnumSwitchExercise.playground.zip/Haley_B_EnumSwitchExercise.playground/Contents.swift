import UIKit

enum mySandwich {
    case lettuce
    case turkey
    case mayo
    case bananapeppers
    case eggs
}
var sandwich = mySandwich.lettuce

switch sandwich {
case .eggs:
print ("My sandwich has eggs")
case .lettuce:
    print("My sandwich has lettuce")
case .turkey:
    print("My sandwich has turkey")
case .mayo:
    print("My sandwich has mayo")
case .bananapeppers:
    print("My sandwich has bananapeppers")
}
